import React, { useState } from 'react';
import { Menu, X, ChevronDown, Star, Users, Zap, MessageSquare, CheckCircle } from 'lucide-react';

const App: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <a href="#" className="flex items-center">
                <Zap className="h-8 w-8 text-indigo-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">Horizon</span>
              </a>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#features" className="text-gray-600 hover:text-indigo-600 transition-colors">Features</a>
              <a href="#testimonials" className="text-gray-600 hover:text-indigo-600 transition-colors">Testimonials</a>
              <a href="#pricing" className="text-gray-600 hover:text-indigo-600 transition-colors">Pricing</a>
              <a href="#contact" className="text-gray-600 hover:text-indigo-600 transition-colors">Contact</a>
              <a href="#" className="px-5 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors">
                Get Started
              </a>
            </div>

            {/* Mobile menu button */}
            <div className="flex md:hidden">
              <button
                type="button"
                className="text-gray-500 hover:text-gray-700 focus:outline-none"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-b border-gray-100">
            <div className="container mx-auto px-4 py-4 space-y-3">
              <a href="#features" className="block text-gray-600 hover:text-indigo-600 transition-colors">Features</a>
              <a href="#testimonials" className="block text-gray-600 hover:text-indigo-600 transition-colors">Testimonials</a>
              <a href="#pricing" className="block text-gray-600 hover:text-indigo-600 transition-colors">Pricing</a>
              <a href="#contact" className="block text-gray-600 hover:text-indigo-600 transition-colors">Contact</a>
              <a href="#" className="block px-5 py-2 bg-indigo-600 text-white text-center rounded-md hover:bg-indigo-700 transition-colors">
                Get Started
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="py-20 md:py-28">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Build Beautiful Experiences for the Modern Web
            </h1>
            <p className="mt-6 text-xl text-gray-600 leading-relaxed">
              Create stunning interfaces that captivate your audience with our comprehensive design system. 
              Horizon helps you build faster and deliver exceptional user experiences.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row justify-center gap-4">
              <a href="#" className="px-8 py-3 bg-indigo-600 text-white font-medium rounded-md shadow-md hover:bg-indigo-700 transition-colors">
                Get Started
              </a>
              <a href="#" className="px-8 py-3 border border-gray-300 text-gray-700 font-medium rounded-md hover:border-gray-400 transition-colors">
                Learn More
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-10">
              <p className="text-gray-500 text-sm uppercase tracking-wider">Trusted by industry leaders</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 justify-items-center items-center opacity-80">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-6 bg-gray-400/20 rounded w-24 md:w-28"></div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 md:py-28">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Features Designed for Modern Teams
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Everything you need to create exceptional digital experiences with minimal effort.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Feature 1 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <Zap className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Lightning Fast</h3>
              <p className="text-gray-600">
                Optimized for speed and performance, ensuring your applications load in milliseconds, not seconds.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <Users className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Team Collaboration</h3>
              <p className="text-gray-600">
                Work together seamlessly with real-time updates and intuitive sharing capabilities.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <MessageSquare className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Instant Feedback</h3>
              <p className="text-gray-600">
                Collect and implement user feedback faster with our integrated communication tools.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <CheckCircle className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Quality Assurance</h3>
              <p className="text-gray-600">
                Built-in testing and validation to ensure your projects meet the highest standards.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <Star className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Premium Resources</h3>
              <p className="text-gray-600">
                Access a library of high-quality assets, components, and templates to accelerate your workflow.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <div className="h-12 w-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                <ChevronDown className="h-6 w-6 text-indigo-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Expandable Platform</h3>
              <p className="text-gray-600">
                Easily extend functionality with our plugin architecture and comprehensive API documentation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 md:py-28 bg-gradient-to-b from-indigo-50 to-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              What Our Customers Say
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Join thousands of satisfied teams that trust Horizon for their projects.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Testimonial 1 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 relative">
              <div className="flex items-center mb-6">
                <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                <div className="ml-4">
                  <h4 className="text-lg font-semibold text-gray-900">Sarah Johnson</h4>
                  <p className="text-sm text-gray-600">Product Manager, TechCorp</p>
                </div>
              </div>
              <p className="text-gray-600">
                "Horizon has completely transformed our design workflow. We're now able to deliver projects in half the time with twice the quality."
              </p>
              <div className="absolute top-8 right-8 text-indigo-200">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16.25 10H6.25L6.25 20C6.25 25.375 10.625 29.75 16 29.75V24.75C13.25 24.75 11.25 22.75 11.25 20V15H16.25V10Z" fill="currentColor"/>
                  <path d="M33.75 10H23.75V20C23.75 25.375 28.125 29.75 33.5 29.75V24.75C30.75 24.75 28.75 22.75 28.75 20V15H33.75V10Z" fill="currentColor"/>
                </svg>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 relative">
              <div className="flex items-center mb-6">
                <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                <div className="ml-4">
                  <h4 className="text-lg font-semibold text-gray-900">Mark Thompson</h4>
                  <p className="text-sm text-gray-600">CTO, Innovate Inc.</p>
                </div>
              </div>
              <p className="text-gray-600">
                "The collaboration features are unmatched. Our teams can now work together seamlessly regardless of their physical location."
              </p>
              <div className="absolute top-8 right-8 text-indigo-200">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16.25 10H6.25L6.25 20C6.25 25.375 10.625 29.75 16 29.75V24.75C13.25 24.75 11.25 22.75 11.25 20V15H16.25V10Z" fill="currentColor"/>
                  <path d="M33.75 10H23.75V20C23.75 25.375 28.125 29.75 33.5 29.75V24.75C30.75 24.75 28.75 22.75 28.75 20V15H33.75V10Z" fill="currentColor"/>
                </svg>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 relative">
              <div className="flex items-center mb-6">
                <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
                <div className="ml-4">
                  <h4 className="text-lg font-semibold text-gray-900">Lisa Williams</h4>
                  <p className="text-sm text-gray-600">Design Lead, Creative Studios</p>
                </div>
              </div>
              <p className="text-gray-600">
                "As a design-focused agency, we needed a solution that wouldn't compromise on aesthetics. Horizon delivers exactly that."
              </p>
              <div className="absolute top-8 right-8 text-indigo-200">
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16.25 10H6.25L6.25 20C6.25 25.375 10.625 29.75 16 29.75V24.75C13.25 24.75 11.25 22.75 11.25 20V15H16.25V10Z" fill="currentColor"/>
                  <path d="M33.75 10H23.75V20C23.75 25.375 28.125 29.75 33.5 29.75V24.75C30.75 24.75 28.75 22.75 28.75 20V15H33.75V10Z" fill="currentColor"/>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 md:py-28">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              Simple, Transparent Pricing
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Choose the plan that's right for you and your team.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Basic Plan */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Basic</h3>
              <p className="text-gray-600 mb-6">For individuals and small projects</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-gray-900">$19</span>
                <span className="text-gray-600">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Up to 5 projects</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Basic templates</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Community support</span>
                </li>
                <li className="flex items-center opacity-50">
                  <X className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-600">Team collaboration</span>
                </li>
                <li className="flex items-center opacity-50">
                  <X className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-600">Advanced analytics</span>
                </li>
              </ul>
              <a href="#" className="block w-full py-3 px-4 text-center bg-white border border-indigo-600 text-indigo-600 font-medium rounded-md hover:bg-indigo-50 transition-colors">
                Get Started
              </a>
            </div>

            {/* Pro Plan */}
            <div className="bg-white rounded-lg p-8 shadow-md border border-indigo-100 hover:shadow-lg transition-shadow relative">
              <div className="absolute top-0 right-0 bg-indigo-600 text-white text-xs font-bold uppercase py-1 px-3 rounded-bl-lg rounded-tr-lg">
                Popular
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Pro</h3>
              <p className="text-gray-600 mb-6">For professionals and growing teams</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-gray-900">$49</span>
                <span className="text-gray-600">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Unlimited projects</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Premium templates</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Priority support</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Team collaboration</span>
                </li>
                <li className="flex items-center opacity-50">
                  <X className="h-5 w-5 text-gray-400 mr-2" />
                  <span className="text-gray-600">Advanced analytics</span>
                </li>
              </ul>
              <a href="#" className="block w-full py-3 px-4 text-center bg-indigo-600 text-white font-medium rounded-md hover:bg-indigo-700 transition-colors">
                Get Started
              </a>
            </div>

            {/* Enterprise Plan */}
            <div className="bg-white rounded-lg p-8 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Enterprise</h3>
              <p className="text-gray-600 mb-6">For large teams and organizations</p>
              <div className="mb-6">
                <span className="text-4xl font-bold text-gray-900">$99</span>
                <span className="text-gray-600">/month</span>
              </div>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Unlimited projects</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">All templates & resources</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">24/7 dedicated support</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Advanced team features</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-gray-600">Advanced analytics</span>
                </li>
              </ul>
              <a href="#" className="block w-full py-3 px-4 text-center bg-white border border-indigo-600 text-indigo-600 font-medium rounded-md hover:bg-indigo-50 transition-colors">
                Contact Sales
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section id="contact" className="py-20 md:py-28 bg-indigo-600">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Stay Updated with Our Newsletter
            </h2>
            <p className="mt-4 text-xl text-indigo-200">
              Get the latest news, updates, and tips delivered directly to your inbox.
            </p>
            <div className="mt-10">
              <form className="sm:flex justify-center gap-4">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full sm:w-96 px-5 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-300 mb-3 sm:mb-0"
                />
                <button type="submit" className="w-full sm:w-auto bg-white text-indigo-600 font-medium px-6 py-3 rounded-md hover:bg-gray-100 transition-colors">
                  Subscribe
                </button>
              </form>
              <p className="mt-4 text-sm text-indigo-200">
                We respect your privacy. Unsubscribe at any time.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <Zap className="h-8 w-8 text-indigo-400" />
                <span className="ml-2 text-xl font-bold text-white">Horizon</span>
              </div>
              <p className="mb-4">
                Building the future of web design with powerful, intuitive tools.
              </p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z"/>
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors">
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm-2.917 16.083c-2.258 0-4.083-1.825-4.083-4.083s1.825-4.083 4.083-4.083c1.103 0 2.024.402 2.735 1.067l-1.107 1.068c-.304-.292-.834-.63-1.628-.63-1.394 0-2.531 1.155-2.531 2.579 0 1.424 1.138 2.579 2.531 2.579 1.616 0 2.224-1.162 2.316-1.762h-2.316v-1.4h3.855c.036.204.064.408.064.677.001 2.332-1.563 3.988-3.919 3.988zm9.917-3.5h-1.75v1.75h-1.167v-1.75h-1.75v-1.166h1.75v-1.75h1.167v1.75h1.75v1.166z"/>
                  </svg>
                </a>
              </div>
            </div>
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">Product</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition-colors">Features</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Testimonials</a></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">Company</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white text-lg font-semibold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Cookie Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">GDPR</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center">
            <p>© {new Date().getFullYear()} Horizon. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;